import { useEffect, useState } from 'react';

const API = 'http://localhost:8080/api/feedback';

export default function App() {
  const [customerName, setCustomerName] = useState('');
  const [message, setMessage] = useState('');
  const [feedback, setFeedback] = useState([]);
  const [stats, setStats] = useState({ total: 0, positive: 0, negative: 0, neutral: 0 });
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(false);

  async function load() {
    try {
      const [items, summary] = await Promise.all([fetch(API), fetch(`${API}/stats`)]);
      if (!items.ok || !summary.ok) throw new Error('Backend request failed');
      setFeedback(await items.json());
      setStats(await summary.json());
    } catch {
      setNotice('Cannot connect to backend. Start the AI service and Spring Boot backend first.');
    }
  }
  useEffect(() => { load(); }, []);

  async function submit(e) {
    e.preventDefault();
    setLoading(true); setNotice('');
    try {
      const response = await fetch(API, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerName, message })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not save feedback');
      setCustomerName(''); setMessage('');
      setNotice(`Feedback analyzed: ${result.sentiment} / ${result.category}`);
      await load();
    } catch (err) { setNotice(err.message); }
    finally { setLoading(false); }
  }

  return <main className="container">
    <header><div><p className="eyebrow">AI-POWERED CUSTOMER INSIGHTS</p><h1>Customer Feedback Analysis</h1><p className="muted">Collect feedback, classify sentiment and understand customer experience.</p></div><span className="tag">Portfolio MVP</span></header>
    <section className="stats">
      {Object.entries(stats).map(([key, value]) => <article className="stat" key={key}><span>{key.toUpperCase()}</span><strong>{value}</strong></article>)}
    </section>
    <section className="panel">
      <h2>Analyze new feedback</h2>
      <form onSubmit={submit}>
        <label>Customer name<input value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="e.g. Anu" required /></label>
        <label>Customer feedback<textarea value={message} onChange={e => setMessage(e.target.value)} placeholder="Write a product or service review..." rows="4" required /></label>
        <button disabled={loading}>{loading ? 'Analyzing...' : 'Analyze feedback'}</button>
      </form>
      {notice && <p className="notice" role="status">{notice}</p>}
    </section>
    <section className="panel">
      <div className="section-title"><h2>Recent feedback</h2><button className="secondary" onClick={load}>Refresh</button></div>
      {feedback.length === 0 ? <p className="muted">No feedback submitted yet.</p> : <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Feedback</th><th>Sentiment</th><th>Category</th><th>Confidence</th></tr></thead><tbody>
        {feedback.slice().reverse().map(item => <tr key={item.id}><td>{item.customerName}</td><td>{item.message}</td><td><span className={`sentiment ${item.sentiment.toLowerCase()}`}>{item.sentiment}</span></td><td>{item.category}</td><td>{(item.confidence * 100).toFixed(0)}%</td></tr>)}
      </tbody></table></div>}
    </section>
    <footer>Learning project · React + Spring Boot + MySQL + Python NLP</footer>
  </main>;
}

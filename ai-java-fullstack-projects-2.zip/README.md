# AI + Java Full Stack Projects

This starter pack contains three project blueprints and a runnable MVP for **AI Customer Feedback Analysis System**.

## Projects included
1. AI Customer Feedback Analysis System (implemented starter)
2. AI Resume Screening System (blueprint)
3. AI Student Interest & Course Recommendation System (blueprint)

## Tech stack
- Frontend: React + Vite
- Backend: Java 17+, Spring Boot 3, Spring Web, Spring Data JPA
- Database: MySQL 8+
- AI service: Python + FastAPI (baseline sentiment classifier)

## Run the MVP

### 1. Database
Create a MySQL database and user, then run `database/schema.sql`.

### 2. AI service
```bash
cd ai-service
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8001
```

### 3. Java backend
Set environment variables (or edit `backend/src/main/resources/application.properties`):
- `DB_URL` default: `jdbc:mysql://localhost:3306/feedback_ai`
- `DB_USERNAME` default: `root`
- `DB_PASSWORD` default: empty
- `AI_SERVICE_URL` default: `http://localhost:8001`

Then:
```bash
cd backend
mvn spring-boot:run
```
API runs at `http://localhost:8080`.

### 4. React frontend
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal.

## API
- `POST /api/feedback` with JSON `{"customerName":"Anu","message":"Delivery was late but product is good"}`
- `GET /api/feedback`
- `GET /api/feedback/stats`

The Python service provides `POST /analyze` with `{"text":"..."}`. This starter uses a transparent keyword baseline, not a production-grade trained model. Replace it with a trained model or transformer pipeline for a stronger AI portfolio project.

## Important
This is a learning starter, not a production-ready system. Add authentication, authorization, validation, pagination, tests, and deployment hardening before production use.

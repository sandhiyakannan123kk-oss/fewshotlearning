from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="Customer Feedback AI Service", version="1.0.0")

POSITIVE = {"good", "great", "excellent", "love", "fast", "helpful", "happy", "perfect", "quality", "easy"}
NEGATIVE = {"bad", "poor", "late", "delay", "broken", "hate", "slow", "rude", "refund", "worst", "damaged"}

class FeedbackRequest(BaseModel):
    text: str = Field(min_length=2, max_length=5000)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/analyze")
def analyze(payload: FeedbackRequest):
    words = {w.strip(".,!?;:()[]{}\"'").lower() for w in payload.text.split()}
    pos = len(words & POSITIVE)
    neg = len(words & NEGATIVE)
    if pos > neg:
        sentiment, confidence = "POSITIVE", min(0.99, 0.60 + 0.10 * (pos-neg))
    elif neg > pos:
        sentiment, confidence = "NEGATIVE", min(0.99, 0.60 + 0.10 * (neg-pos))
    else:
        sentiment, confidence = "NEUTRAL", 0.60
    category = "DELIVERY" if words & {"delivery", "late", "delay", "shipping"} else (
        "PRODUCT_QUALITY" if words & {"quality", "broken", "damaged"} else "GENERAL"
    )
    return {"sentiment": sentiment, "category": category, "confidence": round(confidence, 4)}

# AI Student Interest & Course Recommendation System — Project Blueprint

**Goal:** Collect student interests, skills and goals, then recommend relevant learning paths and courses.

**Stack:** React, Java Spring Boot, MySQL, Python FastAPI, NLP and recommendation models.

**Core modules**
1. Student profile and interest questionnaire
2. Skill and interest text analysis
3. Course catalogue and tagging
4. Recommendation ranking
5. Explanation: why each course was recommended
6. Student dashboard and feedback on recommendations

**Suggested tables:** students, interests, skills, courses, course_skills, recommendations, recommendation_feedback.

**Evaluation:** Track precision@k, student feedback and recommendation acceptance. Avoid claiming predictions are certain.

# AI Resume Screening System — Project Blueprint

**Goal:** Upload resumes, extract skills and experience, compare them with a job description, and provide a transparent match score.

**Stack:** React, Java Spring Boot, MySQL, Python FastAPI, NLP/PDF text extraction.

**Core modules**
1. Candidate and recruiter login (Spring Security)
2. Resume upload and PDF/DOCX text extraction
3. Skill/entity extraction with NLP
4. Job description management
5. Resume-to-job matching with explainable skill overlap
6. Recruiter dashboard and candidate shortlist

**Suggested tables:** users, candidates, resumes, job_posts, extracted_skills, match_results.

**Important:** Do not use an automated score as the sole basis for hiring decisions. Show extracted evidence and allow human review.

package com.portfolio.feedback;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "feedback")
public class Feedback {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name="customer_name", nullable=false, length=120)
    private String customerName;
    @Column(nullable=false, columnDefinition="TEXT")
    private String message;
    @Column(nullable=false, length=20)
    private String sentiment;
    @Column(nullable=false, length=80)
    private String category;
    @Column(nullable=false)
    private double confidence;
    @Column(name="created_at", nullable=false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getSentiment() { return sentiment; }
    public void setSentiment(String sentiment) { this.sentiment = sentiment; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public double getConfidence() { return confidence; }
    public void setConfidence(double confidence) { this.confidence = confidence; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}

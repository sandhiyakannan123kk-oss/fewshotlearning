package com.portfolio.feedback;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import java.util.*;

@RestController
@RequestMapping("/api/feedback")
@CrossOrigin(origins = "http://localhost:5173")
public class FeedbackController {
    private final FeedbackRepository repository;
    private final RestClient aiClient;

    public FeedbackController(FeedbackRepository repository, @Value("${ai.service.url}") String aiUrl) {
        this.repository = repository;
        this.aiClient = RestClient.builder().baseUrl(aiUrl).build();
    }

    public record CreateFeedbackRequest(String customerName, String message) {}
    public record Analysis(String sentiment, String category, double confidence) {}

    @PostMapping
    public ResponseEntity<?> create(@RequestBody CreateFeedbackRequest request) {
        if (request.customerName() == null || request.customerName().isBlank()
                || request.message() == null || request.message().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Customer name and message are required"));
        }
        Analysis analysis = aiClient.post().uri("/analyze")
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of("text", request.message()))
                .retrieve().body(Analysis.class);

        Feedback feedback = new Feedback();
        feedback.setCustomerName(request.customerName().trim());
        feedback.setMessage(request.message().trim());
        feedback.setSentiment(analysis.sentiment());
        feedback.setCategory(analysis.category());
        feedback.setConfidence(analysis.confidence());
        return ResponseEntity.ok(repository.save(feedback));
    }

    @GetMapping
    public List<Feedback> all() {
        return repository.findAll();
    }

    @GetMapping("/stats")
    public Map<String, Long> stats() {
        return Map.of(
            "total", repository.count(),
            "positive", repository.countBySentiment("POSITIVE"),
            "negative", repository.countBySentiment("NEGATIVE"),
            "neutral", repository.countBySentiment("NEUTRAL")
        );
    }
}
